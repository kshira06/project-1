from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('attendance/add/', views.add_attendance, name='add_attendance'),
    path('material/add/', views.add_material, name='add_material'),
    path('vendor/add/', views.add_vendor, name='add_vendor'),
    path('payroll/add/', views.add_payroll, name='add_payroll'),
]
