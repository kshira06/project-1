from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Attendance, Payroll, Vendor, Material
from .forms import AttendanceForm, PayrollForm, VendorForm, MaterialForm

@login_required
def dashboard(request):
    return render(request, 'core/dashboard.html')

@login_required
def add_attendance(request):
    form = AttendanceForm(request.POST or None)
    if form.is_valid():
        attendance = form.save(commit=False)
        attendance.user = request.user
        attendance.save()
        return redirect('dashboard')
    return render(request, 'core/form.html', {'form': form, 'title': 'Add Attendance'})

@login_required
def add_material(request):
    form = MaterialForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        material = form.save(commit=False)
        material.submitted_by = request.user
        material.save()
        return redirect('dashboard')
    return render(request, 'core/form.html', {'form': form, 'title': 'Add Material'})

@login_required
def add_vendor(request):
    form = VendorForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('dashboard')
    return render(request, 'core/form.html', {'form': form, 'title': 'Add Vendor'})

@login_required
def add_payroll(request):
    form = PayrollForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('dashboard')
    return render(request, 'core/form.html', {'form': form, 'title': 'Add Payroll'})
